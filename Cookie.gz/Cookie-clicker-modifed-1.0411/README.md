cookieclicker
=============

The original game can be found at http://orteil.dashnet.org/cookieclicker/

This copy for, errrr, like, educational purpose. Like, if you want to "educate" yourself offline.
